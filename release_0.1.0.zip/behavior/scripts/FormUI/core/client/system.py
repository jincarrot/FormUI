# -*- coding: utf-8 -*-
import mod.client.extraClientApi as c
from ..config import Namespace, SystemNameServer
from ..utils.ui import isFormScreen

ClientSystem = c.GetClientSystemCls()

class Client(ClientSystem):

    def __init__(self, namespace, systemName):
        ClientSystem.__init__(self, namespace, systemName)
        from ..general.managers.observable import ObservableManager
        from ..general.managers.form import FormManager
        from ..general.managers.control import ControlManager
        from ..general.screen import Screen
        self.observableManager = ObservableManager()
        self.formManager = FormManager()
        self.controlManager = ControlManager()
        self.screen = Screen()
        self.listenEvents()

    def listenEvents(self):
        self.ListenForEvent(c.GetEngineNamespace(), c.GetEngineSystemName(), "UiInitFinished", self, self.UIInit)
        self.ListenForEvent(Namespace, SystemNameServer, "applyObservableUpdate", self, self.applyObservableUpdate)
        self.ListenForEvent(Namespace, SystemNameServer, "registerControl", self, self.registerControl)
        self.ListenForEvent(Namespace, SystemNameServer, "showForm", self, self.showForm)
        self.ListenForEvent(Namespace, SystemNameServer, "closeForm", self, self.closeForm)
        self.ListenForEvent(Namespace, SystemNameServer, "setDefaultStyle", self, self.setDefaultStyle)

    def UIInit(self, data):
        from ..general.controls.oreui import OreUI
        OreUI()
        from ..config import Namespace
        c.RegisterUI(Namespace, "screen", Client.__module__.split("system")[0] + "ui.screen.Screen", "fui.screen")
        print("[INFO] FormUI registered.")

    def applyObservableUpdate(self, data):
        id = data['id']
        value = data['value']
        topScreen = c.GetTopScreen()
        if topScreen:
            if isFormScreen(topScreen):
                topScreen.applyObservableUpdate(id, value)
        
    def registerControl(self, data):
        self.controlManager.create(data['type'], data['name'], data['path'], data['options'])

    def onButtonTrigger(self, data):
        form = self.formManager.get(data['formId'])
        if form:
            form._btnCallbacks[data['callbackId']]()

    def showForm(self, data):
        topScreen = c.GetTopScreen()
        if isFormScreen(topScreen):
            topScreen.addForm(data)
        else:
            c.PushScreen(Namespace, "screen", {})
            def pushFormScreen(data):
                topScreen = c.GetTopScreen()
                if isFormScreen(topScreen) and topScreen.isAllReady():
                    c.GetEngineCompFactory().CreateGame(c.GetLevelId()).CancelTimer(timerId)
                    topScreen.addForm(data)
            timerId = c.GetEngineCompFactory().CreateGame(c.GetLevelId()).AddRepeatedTimer(0.05, pushFormScreen, data)

    def closeForm(self, data):
        closeAll = data.get("closeAll", False)
        topScreen = c.GetTopScreen()
        if isFormScreen(topScreen):
            if closeAll:
                while topScreen.forms:
                    topScreen.onClose({"AddTouchEventParams": {"formId": topScreen.forms.keys()[0]}, "closeByInterface": True})
            else:
                topScreen.onClose({"AddTouchEventParams": {"formId": data['formId']}, "closeByInterface": True})

    def setDefaultStyle(self, data):
        self.screen.setDefaultStyle(data['controlType'], data['style'])
